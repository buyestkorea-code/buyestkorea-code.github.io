import React from "react";
import { AbsoluteFill, Img, Sequence, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";

export const FPS = 30;
const INTRO_S = 1.2; // 훅이 없을 때만 쓰는 브랜드 인트로
const HOOK_S = 1.8; // 훅 문구가 첫 사진 위에 떠 있는 시간
const OUTRO_S = 2.5;

// 인스타 릴스 화면(1080×1920)에서 캡션·버튼이 덮는 곳을 비운다: 위 230px, 1440px 아래, 오른쪽 230px
const SAFE = { top: 230, bottom: 1920 - 1440, right: 230, left: 72 };

export type ProductReelProps = {
  brand: "buyest" | "kids";
  brandName: string;
  productName: string;
  price: string;
  cta: string;
  secondsPerPhoto: number;
  photos: string[];
  hook?: string; // 0~2초 첫 문장. 있으면 로고 인트로 대신 첫 사진 위에 바로 뜬다
  lines?: string[]; // 두 번째 사진부터 한 줄씩 붙는 화면 글자
};

const hasHook = (p: ProductReelProps) => !!(p.hook && p.hook.trim());

export const reelDuration = (p: ProductReelProps) =>
  Math.round(((hasHook(p) ? 0 : INTRO_S) + Math.max(p.photos.length, 1) * p.secondsPerPhoto + OUTRO_S) * FPS);

const THEMES = {
  buyest: { bg: "#0d0d0d", fg: "#f5f1ea", accent: "#c8a96a", label: "BUYEST", font: "'Didot','Bodoni 72','Times New Roman',serif", textFont: "'Pretendard','Apple SD Gothic Neo','Malgun Gothic',sans-serif" },
  kids: { bg: "#fbf6ef", fg: "#2b2b2b", accent: "#e8a0a0", label: "BUYEST KIDS", font: "'Avenir Next','Helvetica Neue',Arial,sans-serif", textFont: "'Pretendard','Apple SD Gothic Neo','Malgun Gothic',sans-serif" },
};

const Photo: React.FC<{ src: string; index: number; frames: number }> = ({ src, index, frames }) => {
  const f = useCurrentFrame();
  const zoomIn = index % 2 === 0;
  const scale = interpolate(f, [0, frames], zoomIn ? [1.0, 1.12] : [1.12, 1.0]);
  const x = interpolate(f, [0, frames], index % 3 === 0 ? [-20, 20] : [20, -20]);
  // 훅이 있는 첫 사진은 페이드인 없이 바로 보여야 한다 (첫 프레임이 검은 화면이면 넘겨진다)
  const opacity = interpolate(f, [0, 8, frames - 8, frames], [index === 0 ? 1 : 0, 1, 1, 0], { extrapolateRight: "clamp" });
  return (
    <AbsoluteFill style={{ opacity }}>
      <Img src={src} style={{ width: "100%", height: "100%", objectFit: "cover", transform: `scale(${scale}) translateX(${x}px)` }} />
    </AbsoluteFill>
  );
};

// 안전 영역 안에 문구를 놓는 상자
const SafeText: React.FC<{ children: React.ReactNode; align?: "flex-start" | "center" | "flex-end" }> = ({ children, align = "flex-end" }) => (
  <AbsoluteFill style={{ paddingTop: SAFE.top, paddingBottom: SAFE.bottom, paddingLeft: SAFE.left, paddingRight: SAFE.right, justifyContent: align }}>
    {children}
  </AbsoluteFill>
);

const OnScreen: React.FC<{ text: string; t: (typeof THEMES)["buyest"]; size?: number; delay?: number }> = ({ text, t, size = 68, delay = 0 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: { damping: 200 } });
  return (
    <div
      style={{
        fontFamily: t.textFont, fontSize: size, fontWeight: 700, lineHeight: 1.3, color: t.fg, whiteSpace: "pre-wrap", wordBreak: "keep-all",
        background: `${t.bg}cc`, padding: "20px 28px", borderLeft: `6px solid ${t.accent}`, borderRadius: 6, alignSelf: "flex-start",
        opacity: p, transform: `translateY(${(1 - p) * 30}px)`,
      }}
    >
      {text}
    </div>
  );
};

export const ProductReel: React.FC<ProductReelProps> = (props) => {
  const { fps } = useVideoConfig();
  const frame = useCurrentFrame();
  const t = THEMES[props.brand] ?? THEMES.buyest;
  const withHook = hasHook(props);
  const intro = withHook ? 0 : Math.round(INTRO_S * fps);
  const per = Math.round(props.secondsPerPhoto * fps);
  const hookFrames = Math.min(Math.round(HOOK_S * fps), per);
  const outroStart = intro + per * props.photos.length;
  const lines = (props.lines || []).map((s) => s.trim());
  const pop = (start: number) => spring({ frame: frame - start, fps, config: { damping: 200 } });

  return (
    <AbsoluteFill style={{ backgroundColor: t.bg, color: t.fg, fontFamily: t.font }}>
      {/* 인트로: 훅이 없을 때만 브랜드 라벨 */}
      {!withHook && (
        <Sequence durationInFrames={intro}>
          <AbsoluteFill style={{ justifyContent: "center", alignItems: "center" }}>
            <div style={{ fontSize: 96, letterSpacing: 18, opacity: pop(0), transform: `translateY(${(1 - pop(0)) * 40}px)` }}>{t.label}</div>
            <div style={{ width: 160 * pop(6), height: 3, background: t.accent, marginTop: 28 }} />
          </AbsoluteFill>
        </Sequence>
      )}

      {/* 상품 사진 슬라이드 (팬/줌) */}
      {props.photos.map((src, i) => (
        <Sequence key={i} from={intro + i * per} durationInFrames={per}>
          <Photo src={src} index={i} frames={per} />
        </Sequence>
      ))}

      {/* 사진마다 화면 글자. 훅이 있으면 첫 사진은 훅, 두 번째 사진부터 lines[0], lines[1] … */}
      {props.photos.map((_, i) => {
        const line = withHook ? (i === 0 ? "" : lines[i - 1]) : lines[i];
        const start = intro + i * per;
        if (withHook && i === 0) return null;
        return (
          <Sequence key={`t${i}`} from={start} durationInFrames={per}>
            {line ? (
              <SafeText>
                <OnScreen text={line} t={t} delay={4} />
              </SafeText>
            ) : (
              <SafeText>
                <div style={{ background: `linear-gradient(transparent, ${t.bg}dd)`, padding: "60px 28px 28px", borderRadius: 6 }}>
                  <div style={{ fontSize: 40, letterSpacing: 8, color: t.accent }}>{props.brandName.toUpperCase()}</div>
                  <div style={{ fontFamily: t.textFont, fontSize: 60, marginTop: 10, lineHeight: 1.25, wordBreak: "keep-all" }}>{props.productName}</div>
                </div>
              </SafeText>
            )}
          </Sequence>
        );
      })}

      {/* 0~2초 훅: 첫 프레임부터 바로 보인다 */}
      {withHook && (
        <Sequence durationInFrames={hookFrames}>
          <AbsoluteFill style={{ background: `linear-gradient(${t.bg}00 30%, ${t.bg}99 100%)` }} />
          <SafeText align="center">
            <div style={{ fontSize: 34, letterSpacing: 10, color: t.accent, marginBottom: 24 }}>{t.label}</div>
            <div
              style={{
                fontFamily: t.textFont, fontSize: 84, fontWeight: 800, lineHeight: 1.25, color: t.fg, wordBreak: "keep-all", whiteSpace: "pre-wrap",
                textShadow: props.brand === "kids" ? "none" : "0 4px 24px rgba(0,0,0,.55)",
                background: props.brand === "kids" ? `${t.bg}dd` : "transparent", padding: props.brand === "kids" ? "20px 28px" : 0, borderRadius: 8,
              }}
            >
              {props.hook}
            </div>
          </SafeText>
        </Sequence>
      )}

      {/* 아웃트로: 가격 + CTA (안전 영역 안) */}
      <Sequence from={outroStart}>
        <AbsoluteFill style={{ backgroundColor: t.bg }} />
        <SafeText align="center">
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: 44, letterSpacing: 10, color: t.accent, opacity: pop(outroStart) }}>{props.brandName.toUpperCase()}</div>
            <div style={{ fontFamily: t.textFont, fontSize: 64, marginTop: 20, lineHeight: 1.25, wordBreak: "keep-all", opacity: pop(outroStart + 4) }}>{props.productName}</div>
            {props.price && <div style={{ fontSize: 100, marginTop: 40, fontWeight: 600, opacity: pop(outroStart + 10) }}>{props.price}</div>}
            {props.cta && (
              <div style={{ display: "inline-block", fontFamily: t.textFont, marginTop: 56, fontSize: 42, padding: "20px 44px", border: `2px solid ${t.accent}`, borderRadius: 999, opacity: pop(outroStart + 18) }}>
                {props.cta}
              </div>
            )}
            <div style={{ marginTop: 64, fontSize: 32, letterSpacing: 12, opacity: 0.7 }}>{t.label}</div>
          </div>
        </SafeText>
      </Sequence>
    </AbsoluteFill>
  );
};
