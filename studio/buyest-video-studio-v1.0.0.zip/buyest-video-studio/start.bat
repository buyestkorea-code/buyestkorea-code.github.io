@echo off
title BUYEST Video Studio (do not close this window)
cd /d "%~dp0"

rem This file is NOT replaced by updates. Keep it simple and ASCII-only.
set CLAUDE_HEADLESS=0
set RESTARTS=0

rem Open the browser once, unless started automatically at login ("auto")
if /i not "%~1"=="auto" start "" cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:3939"

:loop
node server.js
rem Exit code 42 = update applied, restart (at most 3 times, to avoid runaway loops)
if %errorlevel%==42 (
  set /a RESTARTS+=1
  if %RESTARTS% LEQ 3 (
    echo Update applied. Restarting...
    timeout /t 2 /nobreak >nul
    goto loop
  )
)
if errorlevel 1 pause
