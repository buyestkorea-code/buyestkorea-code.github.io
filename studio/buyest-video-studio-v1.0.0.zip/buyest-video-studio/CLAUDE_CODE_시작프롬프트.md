# Claude Code 시작 프롬프트 — BUYEST 영상 스튜디오 (배포 단계)

이 폴더에서 `claude` 를 실행하고 아래 블록을 붙여넣으세요.

```
실장, 이 폴더는 BUYEST 영상 스튜디오야. 먼저 CLAUDE.md 와 docs\직원-사용법.md 를 읽어.

구조: 직원 각자의 PC가 렌더 서버. 툴키트(buyestkorea-code.github.io)에는 studio/ 폴더(설치파일·latest.json·zip·안내페이지)와 카드만 올라간다.

1) 이 PC에서 실제 점검 (안 해본 것만)
   - python release-tools\build_release.py "첫 배포" 로 release\studio\ 생성
   - release\studio 를 임시로 로컬 웹서버(예: python -m http.server 8765)로 띄우고
     BUYEST_STUDIO_BASE=http://127.0.0.1:8765 BUYEST_STUDIO_DIR/DESKTOP_DIR/STARTUP_DIR/NO_LAUNCH 로 install.ps1 을 임시 폴더에 시험 설치 (바탕화면·시작프로그램은 건드리지 마)
   - 실제 직원 계정 1개로 로그인 → ① 릴스 렌더 1회 → MP4 다운로드까지 확인
   - ② HyperFrames: "키즈-신상-타이틀" 템플릿 + 사진 2장으로 렌더 1회 확인 (안 되면 템플릿 수정)
   - .bat 파일 테스트할 땐 반드시 "auto" 인자를 줘서 브라우저가 열리지 않게 해.

2) 툴키트 배포 (push 전에 변경 diff 를 보여주고 내 확인을 받아)
   - 툴키트 저장소 clone/fetch (다른 세션이 동시 작업 중이니 push 전에 반드시 fetch)
   - release\studio\* 를 저장소의 studio\ 에 복사
   - toolkit-card.html 을 index.html 의 도구 카드 목록에 같은 스타일로 삽입 (index.html 전체 재작성 금지, Edit 로 위치만 찾아 삽입)
   - 로그인 안 한 사람(게스트)에게는 기존 '로그인 필요' 방식으로 카드가 잠기게 처리

3) 직원 안내: docs\직원-사용법.md 를 사장님이 읽을 수 있게 요약해서 보고

주의
- Remotion 은 직원 4명 이상 회사면 유료 Company License 대상. 직원 수 물어보고 해당되면 따로 알려줘.
- 렌더·서버 코드를 고쳤으면 실제 렌더 1회로 확인하고 "완료"라고 해. version 도 올려.
```
