# BUYEST 영상 스튜디오 — 프로젝트 안내 (Claude Code용)

## 목적
직원들이 한 페이지(public/index.html)에서 세 가지 영상 도구를 쓰는 사내 도구.
- ① Remotion — 상품 사진 → 9:16 상품 릴스 자동 생성 (remotion/ProductReel.tsx)
- ② HyperFrames — HTML 컴포지션으로 촬영본 위 자막·그래픽 합성 (hyperframes-templates/)
- ③ OpenMontage — 기획 브리프 → 에이전트가 스톡·BGM·자막까지 제작 (vendor/OpenMontage)

## 구조 (각 직원 PC가 렌더 서버)
- server.js — Express 서버(127.0.0.1:3939, 이 PC에서만 접속). 렌더, /api/*, 결과는 out/*.mp4 (7일 뒤 자동 삭제)
- 직원 PC마다 설치: 툴키트 studio/ 페이지의 BUYEST-Studio-Install.bat → install.ps1 (Node·FFmpeg·부품 설치, 바탕화면 아이콘, 로그인 시 자동 시작)
- 업데이트: 서버가 툴키트 studio/latest.json 과 package.json version 을 비교 → 화면에 노란 안내 → "지금 업데이트" 한 번 (zip 내려받아 덮어쓰기 후 종료코드 42 → start.bat 이 재시작)
- 배포 절차는 docs/직원-사용법.md 의 "담당자용" 참고. 코드를 고치면 version 을 반드시 올릴 것
- 배치(.bat) 파일에는 한글을 쓰지 말 것 (cmd 에서 UTF-8 한글이 깨져 엉뚱한 줄이 실행됨 — 실제로 겪음). .ps1 은 UTF-8 BOM 으로 저장
- ③ OpenMontage 탭은 vendor\OpenMontage 가 있는 PC에서만 보임 (원클릭 설치는 ①②만 설치)

## 접근 제어
- 툴키트 직원 계정으로 로그인한 사람만 사용 (server.js /auth/login → toolkit_dashboard_api.php). 세션 쿠키 12시간.
- 작업마다 직원 아이디 기록(jobs/*/meta.json), 완성 영상은 /api/download/:id 로 다운로드 (브랜드_상품명_날짜.mp4)

## 브랜드 규칙
- BUYEST: 검정 #0d0d0d / 아이보리 #f5f1ea / 골드 #c8a96a, 세리프
- BUYEST Kids: 크림 #fbf6ef / 차콜 #2b2b2b / 핑크 #e8a0a0, 산세리프
- 직원용 화면 문구는 모두 한국어

## 작업 규칙
- 팀 호칭은 한글(실장, 디자인팀, 브랜드팀 등)로 지시받음
- 렌더 관련 수정 후에는 반드시 실제로 1회 렌더해서 out/ 에 MP4 가 생기는지 확인
- 라이선스: Remotion 은 직원 4명 이상 회사면 Company License 필요 / OpenMontage 는 AGPL-3.0 (사내 사용은 문제없음, 외부 공개 서비스로 열지 말 것) / HyperFrames 는 Apache-2.0
