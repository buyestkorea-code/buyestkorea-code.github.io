# BUYEST 영상 스튜디오

직원 PC 한 대 안에서 도는 영상 도구 (Remotion 상품 릴스 · HyperFrames 자막 합성 · OpenMontage 기획 영상).
툴키트 직원 계정으로 로그인, 완성 영상은 브라우저에서 다운로드, 7일 지난 파일은 자동 삭제.

- 직원용 안내: `docs/직원-사용법.md`
- 설치/업데이트 배포: `release-tools/build_release.py` → `release/studio/` 를 툴키트 저장소 `studio/` 에 업로드
- 직접 실행(개발): `npm install` → `start.bat`
