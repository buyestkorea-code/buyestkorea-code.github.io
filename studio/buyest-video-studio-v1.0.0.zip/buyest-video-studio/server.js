// BUYEST 영상 스튜디오 서버
// 한 페이지(public/index.html)에서 Remotion / HyperFrames / OpenMontage 를 사용.
// 각 직원 PC에 설치해서 그 PC 안에서만(127.0.0.1) 실행 → 브라우저로 http://localhost:3939 접속. 렌더도 그 PC가 한다.

const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const { spawn } = require("child_process");

const PORT = Number(process.env.PORT || 3939);
const HOST = process.env.HOST || "127.0.0.1"; // 이 PC 안에서만 접속 가능
const ROOT = __dirname;
const JOBS_DIR = path.join(ROOT, "jobs");
const OUT_DIR = path.join(ROOT, "out");
const OPENMONTAGE_DIR = process.env.OPENMONTAGE_DIR || path.join(ROOT, "vendor", "OpenMontage");
const CLAUDE_HEADLESS = process.env.CLAUDE_HEADLESS === "1"; // 1이면 OpenMontage 작업을 claude -p 로 자동 실행
const BROWSER = process.env.REMOTION_BROWSER || null; // 이미 설치된 크롬을 쓸 때 경로 지정
const UPDATE_BASE = process.env.UPDATE_BASE || "https://buyestkorea-code.github.io/studio"; // latest.json + 업데이트 zip 위치
const TOOLKIT_API = process.env.TOOLKIT_API || "https://buyest.co.kr/toolkit_dashboard_api.php"; // 툴키트 직원 계정 확인용

for (const d of [JOBS_DIR, OUT_DIR]) fs.mkdirSync(d, { recursive: true });

const app = express();
app.use(express.json({ limit: "20mb" }));
app.use((req, res, next) => {
  const h = String(req.get("host") || "").toLowerCase();
  if (h === `localhost:${PORT}` || h === `127.0.0.1:${PORT}`) return next();
  res.status(403).send("localhost 로만 접속할 수 있습니다");
});

// ── 로그인: 툴키트 직원 계정으로 확인 ─────────────────────
// 툴키트와 같은 계정(toolkit_dashboard_api.php)으로 로그인한 직원만 사용 가능.
// 승인 대기 중인 가입자는 통과하지 못한다. 비밀번호는 저장하지 않고 세션 쿠키만 발급.
const SESSIONS_FILE = path.join(ROOT, "sessions.json");
const sessions = new Map(); // token -> { id, role, exp }
try { for (const [k, v] of Object.entries(JSON.parse(fs.readFileSync(SESSIONS_FILE, "utf8")))) if (v.exp > Date.now()) sessions.set(k, v); } catch (_) {}
const saveSessions = () => { try { fs.writeFileSync(SESSIONS_FILE, JSON.stringify(Object.fromEntries(sessions))); } catch (_) {} };
const SESSION_MS = 12 * 60 * 60 * 1000;
const failures = new Map(); // ip -> { n, until }

function parseCookies(req) {
  const out = {};
  for (const part of (req.get("cookie") || "").split(";")) {
    const i = part.indexOf("=");
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function currentUser(req) {
  const s = sessions.get(parseCookies(req).studio_session);
  if (!s) return null;
  if (s.exp < Date.now()) { sessions.delete(parseCookies(req).studio_session); return null; }
  return s;
}
const isLoopback = (req) => ["127.0.0.1", "::1", "::ffff:127.0.0.1"].includes(req.socket.remoteAddress);

app.post("/auth/login", async (req, res) => {
  const ip = req.socket.remoteAddress;
  const f = failures.get(ip);
  if (f && f.until > Date.now()) return res.status(429).json({ error: "로그인 시도가 너무 많습니다. 15분 뒤에 다시 시도하세요." });
  const id = String((req.body && req.body.id) || "").trim();
  const pass = String((req.body && req.body.pass) || "");
  if (!id || !pass) return res.status(400).json({ error: "아이디와 비밀번호를 입력하세요" });
  try {
    const r = await fetch(TOOLKIT_API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "login", user: id, pass }) });
    const data = await r.json();
    if (!data || !data.ok || data.status === "pending") {
      const n = ((f && f.n) || 0) + 1;
      failures.set(ip, { n, until: n >= 5 ? Date.now() + 15 * 60 * 1000 : 0 });
      const pending = data && data.ok && data.status === "pending";
      return res.status(401).json({ error: pending ? "관리자 승인 후 사용할 수 있습니다" : (data && data.error) || "로그인 실패" });
    }
    failures.delete(ip);
    const token = crypto.randomBytes(24).toString("hex");
    sessions.set(token, { id, role: data.role || "member", exp: Date.now() + SESSION_MS }); saveSessions();
    res.setHeader("Set-Cookie", `studio_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_MS / 1000}`);
    res.json({ ok: true, id, role: data.role || "member" });
  } catch (e) {
    res.status(502).json({ error: "툴키트 계정 서버에 연결할 수 없습니다. 잠시 후 다시 시도하세요." });
  }
});
app.post("/auth/logout", (req, res) => {
  sessions.delete(parseCookies(req).studio_session); saveSessions();
  res.setHeader("Set-Cookie", "studio_session=; HttpOnly; Path=/; Max-Age=0");
  res.json({ ok: true });
});
app.get("/auth/me", (req, res) => {
  const u = currentUser(req);
  if (!u) return res.status(401).json({ error: "로그인이 필요합니다" });
  res.json({ id: u.id, role: u.role });
});

// 로그인 화면·아이콘 외에는 전부 로그인 필요. (렌더용 크롬이 이 PC에서 사진을 읽는 /jobs 는 본인 PC 접근만 예외)
const PUBLIC_PATHS = new Set(["/login.html", "/favicon.png"]);
app.use((req, res, next) => {
  if (PUBLIC_PATHS.has(req.path) || req.path.startsWith("/auth/")) return next();
  req.user = currentUser(req);
  if (req.user) return next();
  if (req.path.startsWith("/jobs/") && isLoopback(req)) return next();
  if (req.path.startsWith("/api/") || req.path.startsWith("/out/") || req.path.startsWith("/jobs/")) return res.status(401).json({ error: "로그인이 필요합니다" });
  res.redirect("/login.html");
});

app.use(express.static(path.join(ROOT, "public")));
app.use("/jobs", express.static(JOBS_DIR));
app.use("/out", express.static(OUT_DIR));

// ── 작업 상태 (메모리 + 폴더의 meta.json 에 저장 → 서버 재시작해도 내역 유지) ──
const jobs = new Map();
function persist(job) {
  try {
    const { log: _log, ...meta } = job;
    fs.writeFileSync(path.join(JOBS_DIR, job.id, "meta.json"), JSON.stringify(meta), "utf8");
  } catch (_) {}
}
for (const d of fs.readdirSync(JOBS_DIR, { withFileTypes: true })) {
  if (!d.isDirectory()) continue;
  try {
    const job = { log: [], ...JSON.parse(fs.readFileSync(path.join(JOBS_DIR, d.name, "meta.json"), "utf8")) };
    if (job.status === "queued" || job.status === "rendering") { job.status = "error"; job.error = "서버가 재시작되어 작업이 중단되었습니다. 다시 요청해주세요."; }
    jobs.set(job.id, job);
  } catch (_) {}
}
function newJob(tool, meta = {}) {
  const id = `${tool}-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`;
  const dir = path.join(JOBS_DIR, id);
  fs.mkdirSync(dir, { recursive: true });
  const job = { id, tool, status: "queued", progress: 0, log: [], output: null, error: null, createdAt: new Date().toISOString(), ...meta };
  jobs.set(id, job);
  persist(job);
  return { job, dir };
}
// 다운로드 파일명: 브랜드_상품명_날짜.mp4 (없으면 도구명)
function downloadName(job) {
  const clean = (s) => String(s || "").replace(/[\\/:*?"<>|\s]+/g, "_").replace(/^_+|_+$/g, "");
  const parts = [clean(job.brandName), clean(job.productName)].filter(Boolean);
  if (!parts.length) parts.push(job.tool);
  return `${parts.join("_")}_${job.createdAt.slice(0, 10)}.mp4`;
}
function log(job, line) {
  job.log.push(String(line).trimEnd());
  if (job.log.length > 300) job.log.shift();
}
function run(job, cmd, args, opts = {}) {
  return new Promise((resolve, reject) => {
    log(job, `$ ${cmd} ${args.join(" ")}`);
    const p = spawn(cmd, args, { shell: process.platform === "win32", ...opts });
    p.stdout.on("data", (d) => String(d).split(/\r?\n/).filter(Boolean).forEach((l) => log(job, l)));
    p.stderr.on("data", (d) => String(d).split(/\r?\n/).filter(Boolean).forEach((l) => log(job, l)));
    p.on("error", reject);
    p.on("close", (code) => (code === 0 ? resolve() : reject(new Error(`${cmd} 종료 코드 ${code}`))));
  });
}
function findNewestMp4(dir) {
  let best = null;
  const walk = (d) => {
    for (const f of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, f.name);
      if (f.isDirectory() && f.name !== "node_modules") walk(p);
      else if (f.name.toLowerCase().endsWith(".mp4")) {
        const t = fs.statSync(p).mtimeMs;
        if (!best || t > best.t) best = { p, t };
      }
    }
  };
  walk(dir);
  return best && best.p;
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const tmp = path.join(JOBS_DIR, "_uploads");
      fs.mkdirSync(tmp, { recursive: true });
      cb(null, tmp);
    },
    filename: (req, file, cb) => cb(null, `${Date.now()}-${crypto.randomBytes(4).toString("hex")}${path.extname(file.originalname).toLowerCase()}`),
  }),
  limits: { fileSize: 200 * 1024 * 1024, files: 20 },
});

// ── 1) Remotion: 상품 릴스 템플릿 ─────────────────────
let remotionBundle = null;
async function getRemotionBundle(job) {
  if (remotionBundle) return remotionBundle;
  const { bundle } = require("@remotion/bundler");
  log(job, "Remotion 번들 생성 중 (최초 1회)…");
  remotionBundle = await bundle({ entryPoint: path.join(ROOT, "remotion", "index.ts") });
  return remotionBundle;
}

app.post("/api/remotion/render", upload.array("photos", 12), async (req, res) => {
  const files = req.files || [];
  if (!files.length) return res.status(400).json({ error: "사진을 1장 이상 올려주세요" });
  const { job, dir } = newJob("remotion", { user: req.user.id, brandName: req.body.brandName || "", productName: req.body.productName || "" });
  const photoUrls = files.map((f, i) => {
    const name = `photo${i}${path.extname(f.filename)}`;
    fs.renameSync(f.path, path.join(dir, name));
    return `http://127.0.0.1:${PORT}/jobs/${job.id}/${name}`;
  });
  const inputProps = {
    brand: req.body.brand === "kids" ? "kids" : "buyest",
    brandName: req.body.brandName || "",
    productName: req.body.productName || "",
    price: req.body.price || "",
    cta: req.body.cta || "",
    secondsPerPhoto: Math.min(Math.max(Number(req.body.secondsPerPhoto) || 2.5, 1), 6),
    photos: photoUrls,
  };
  res.json({ jobId: job.id });

  try {
    job.status = "rendering";
    const { selectComposition, renderMedia } = require("@remotion/renderer");
    const serveUrl = await getRemotionBundle(job);
    const composition = await selectComposition({ serveUrl, id: "ProductReel", inputProps, browserExecutable: BROWSER });
    const outFile = path.join(OUT_DIR, `${job.id}.mp4`);
    await renderMedia({
      composition, serveUrl, codec: "h264", outputLocation: outFile, inputProps, browserExecutable: BROWSER,
      onProgress: ({ progress }) => { job.progress = Math.round(progress * 100); },
    });
    job.output = `/out/${job.id}.mp4`;
    job.status = "done";
    job.progress = 100;
  } catch (e) {
    job.status = "error"; job.error = e.message; log(job, e.stack || e.message);
  }
  persist(job);
});

// ── 2) HyperFrames: HTML 컴포지션 → MP4 ────────────────
app.get("/api/hyperframes/templates", (req, res) => {
  const dir = path.join(ROOT, "hyperframes-templates");
  const list = fs.readdirSync(dir).filter((f) => f.endsWith(".html"))
    .map((f) => ({ name: f.replace(/\.html$/, ""), html: fs.readFileSync(path.join(dir, f), "utf8") }));
  res.json(list);
});

app.post("/api/hyperframes/render", upload.array("assets", 20), async (req, res) => {
  const html = req.body.html;
  if (!html || !html.includes("data-composition-id")) return res.status(400).json({ error: "HyperFrames HTML(data-composition-id 포함)이 필요합니다" });
  const { job, dir } = newJob("hyperframes", { user: req.user.id });
  const proj = path.join(dir, "project");
  res.json({ jobId: job.id });

  try {
    job.status = "rendering";
    await run(job, "npx", ["--yes", "hyperframes", "init", "project"], { cwd: dir });
    for (const f of req.files || []) fs.renameSync(f.path, path.join(proj, f.originalname.replace(/[^\w.\-가-힣]/g, "_")));
    fs.writeFileSync(path.join(proj, "index.html"), html, "utf8");
    const outFile = path.join(OUT_DIR, `${job.id}.mp4`);
    await run(job, "npx", ["--yes", "hyperframes", "render", "-o", outFile, "--quiet"], { cwd: proj });
    if (!fs.existsSync(outFile)) {
      const mp4 = findNewestMp4(proj); // 혹시 -o 가 무시된 경우 대비
      if (!mp4) throw new Error("렌더 결과 MP4를 찾지 못했습니다");
      fs.copyFileSync(mp4, outFile);
    }
    job.output = `/out/${job.id}.mp4`; job.status = "done"; job.progress = 100;
  } catch (e) {
    job.status = "error"; job.error = e.message; log(job, e.message);
  }
  persist(job);
});

// ── 3) OpenMontage: 기획 브리프 → 에이전트 제작 ─────────
app.post("/api/openmontage/job", async (req, res) => {
  const { brief, pipeline, platform, brand } = req.body || {};
  if (!brief) return res.status(400).json({ error: "영상 기획 내용을 입력해주세요" });
  if (!fs.existsSync(OPENMONTAGE_DIR)) return res.status(500).json({ error: `OpenMontage 폴더가 없습니다: ${OPENMONTAGE_DIR} (setup.bat 실행 필요)` });
  const { job, dir } = newJob("openmontage", { user: req.user.id });
  const brandLabel = brand === "kids" ? "BUYEST Kids (아동 명품 부티크)" : "BUYEST (명품 병행수입)";
  const briefMd = [
    `# BUYEST 영상 제작 요청 (${job.id})`,
    `- 브랜드: ${brandLabel}`,
    `- 파이프라인: ${pipeline || "에이전트가 선택"}`,
    `- 출력 규격: ${platform || "Instagram Reels 9:16"}`,
    `- 결과 MP4 저장 위치: ${path.join(OUT_DIR, job.id + ".mp4")}`,
    "",
    "## 기획",
    brief,
    "",
    "## 규칙",
    "- 실제 브랜드 로고·상표는 직원이 제공한 자료에 있는 것만 사용",
    "- 스톡 소스는 라이선스가 확인되는 무료 소스만 사용",
    "- 한국어 자막",
  ].join("\n");
  fs.writeFileSync(path.join(dir, "brief.md"), briefMd, "utf8");

  if (!CLAUDE_HEADLESS) {
    job.status = "waiting_operator"; persist(job);
    job.instructions = `담당자 PC에서 OpenMontage 폴더를 Claude Code로 열고 다음을 입력: "${path.join(dir, "brief.md")} 내용대로 영상 만들어줘"`;
    return res.json({ jobId: job.id, instructions: job.instructions });
  }

  res.json({ jobId: job.id });
  try {
    job.status = "rendering";
    const prompt = `다음 파일의 요청대로 OpenMontage 파이프라인을 실행해 영상을 완성하고, 최종 MP4를 지정된 위치에 저장해줘: ${path.join(dir, "brief.md")}. 승인 게이트는 브리프 내용을 기준으로 스스로 판단해 진행해.`;
    await run(job, "claude", ["-p", JSON.stringify(prompt), "--permission-mode", "acceptEdits"], { cwd: OPENMONTAGE_DIR });
    const target = path.join(OUT_DIR, `${job.id}.mp4`);
    if (!fs.existsSync(target)) throw new Error("에이전트 작업은 끝났지만 MP4가 저장되지 않았습니다 (로그 확인)");
    job.output = `/out/${job.id}.mp4`; job.status = "done"; job.progress = 100;
  } catch (e) {
    job.status = "error"; job.error = e.message; log(job, e.message);
  }
  persist(job);
});

// ── 7일 지난 작업·영상·사진 자동 삭제 (시작 시 + 6시간마다) ──
const KEEP_MS = 7 * 24 * 60 * 60 * 1000;
function cleanup() {
  const cutoff = Date.now() - KEEP_MS;
  const rm = (p) => { try { fs.rmSync(p, { recursive: true, force: true }); } catch (_) {} };
  for (const [id, job] of jobs) {
    if (job.status === "rendering" || job.status === "queued") continue;
    if (new Date(job.createdAt).getTime() < cutoff) { rm(path.join(JOBS_DIR, id)); rm(path.join(OUT_DIR, `${id}.mp4`)); jobs.delete(id); }
  }
  // 내역에 없는 오래된 파일(업로드 임시 폴더, 고아 파일)도 정리
  for (const dir of [OUT_DIR, path.join(JOBS_DIR, "_uploads")]) {
    if (!fs.existsSync(dir)) continue;
    for (const f of fs.readdirSync(dir)) {
      const p = path.join(dir, f);
      try { if (fs.statSync(p).mtimeMs < cutoff) rm(p); } catch (_) {}
    }
  }
}
cleanup();
setInterval(cleanup, 6 * 60 * 60 * 1000);

// ── 버전 확인 / 원클릭 업데이트 ─────────────────────
// 툴키트 사이트의 studio/latest.json 과 내 버전을 비교 → 새 버전이면 화면에 안내 → 버튼 한 번으로 설치.
const LOCAL_VERSION = require("./package.json").version;
const PROTECTED = new Set(["node_modules", "jobs", "out", "vendor", "sessions.json", ".env", "start.bat"]); // 업데이트가 건드리지 않는 것
const newer = (a, b) => { const x = String(a).split(".").map(Number), y = String(b).split(".").map(Number); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };
let latestCache = { at: 0, data: null };
async function fetchLatest(force) {
  if (!force && Date.now() - latestCache.at < 10 * 60 * 1000) return latestCache.data;
  try {
    const r = await fetch(`${UPDATE_BASE}/latest.json?t=${Date.now()}`, { signal: AbortSignal.timeout(8000) });
    if (!r.ok) throw new Error(r.status);
    latestCache = { at: Date.now(), data: await r.json() };
  } catch (_) { latestCache = { at: Date.now() - 9 * 60 * 1000, data: null }; } // 실패하면 1분 뒤 다시 확인
  return latestCache.data;
}
const update = { phase: "idle", error: null }; // idle | downloading | installing | restarting | error

app.get("/api/version", async (req, res) => {
  const l = await fetchLatest(req.query.force === "1");
  res.json({ current: LOCAL_VERSION, latest: (l && l.version) || null, notes: (l && l.notes) || "", updateAvailable: !!(l && newer(l.version, LOCAL_VERSION)), update });
});

app.post("/api/update", async (req, res) => {
  if (update.phase !== "idle" && update.phase !== "error") return res.status(409).json({ error: "이미 업데이트 중입니다" });
  if ([...jobs.values()].some((j) => j.status === "rendering")) return res.status(409).json({ error: "영상을 만드는 중입니다. 끝난 뒤에 업데이트하세요." });
  const l = await fetchLatest(true);
  if (!l || !newer(l.version, LOCAL_VERSION)) return res.status(400).json({ error: "이미 최신 버전입니다" });
  update.phase = "downloading"; update.error = null;
  res.json({ ok: true, version: l.version });
  try {
    const r = await fetch(`${UPDATE_BASE}/${l.file}`, { signal: AbortSignal.timeout(120000) });
    if (!r.ok) throw new Error(`업데이트 파일을 받지 못했습니다 (${r.status})`);
    const buf = Buffer.from(await r.arrayBuffer());
    if (l.sha256 && crypto.createHash("sha256").update(buf).digest("hex") !== l.sha256) throw new Error("업데이트 파일이 손상되었습니다. 잠시 후 다시 시도하세요.");
    update.phase = "installing";
    const before = fs.readFileSync(path.join(ROOT, "package.json"), "utf8");
    const AdmZip = require("adm-zip");
    for (const e of new AdmZip(buf).getEntries()) {
      if (e.isDirectory) continue;
      const rel = e.entryName.split("/").slice(1).join("/"); // 맨 앞 폴더명 제거
      if (!rel || PROTECTED.has(rel.split("/")[0])) continue;
      const dest = path.resolve(ROOT, rel);
      if (!dest.startsWith(ROOT + path.sep)) continue; // 폴더 밖으로 나가는 경로 차단
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, e.getData());
    }
    const after = fs.readFileSync(path.join(ROOT, "package.json"), "utf8");
    if (JSON.parse(before).dependencies && JSON.stringify(JSON.parse(before).dependencies) !== JSON.stringify(JSON.parse(after).dependencies)) {
      await run({ log: [] }, "npm", ["install", "--omit=dev", "--no-audit", "--no-fund"], { cwd: ROOT });
    }
    update.phase = "restarting";
    setTimeout(() => process.exit(42), 800); // start.bat 이 종료코드 42 를 보면 다시 시작함
  } catch (e) {
    update.phase = "error"; update.error = e.message; console.error("[업데이트 실패]", e.message);
  }
});

// ── 공통: 상태 / 목록 / 헬스체크 ──────────────────────
app.get("/api/jobs/:id", (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: "작업 없음" });
  res.json({ ...job, log: job.log.slice(-40) });
});
// 완성 영상 다운로드 (브랜드_상품명_날짜.mp4 로 저장)
app.get("/api/download/:id", (req, res) => {
  const job = jobs.get(req.params.id);
  const file = job && job.output && path.join(OUT_DIR, path.basename(job.output));
  if (!file || !fs.existsSync(file)) return res.status(404).json({ error: "영상 파일이 없습니다" });
  res.download(file, downloadName(job));
});
app.get("/api/jobs", (req, res) => res.json([...jobs.values()].sort((x, y) => y.createdAt.localeCompare(x.createdAt)).slice(0, 50).map(({ log, ...j }) => j)));

app.get("/api/health", (req, res) => {
  const which = (cmd) => new Promise((r) => { const p = spawn(cmd, ["--version"], { shell: true }); p.on("close", (c) => r(c === 0)); p.on("error", () => r(false)); });
  Promise.all([which("ffmpeg"), which("claude")]).then(([ffmpeg, claude]) =>
    res.json({ node: process.version, ffmpeg, claude, openmontage: fs.existsSync(OPENMONTAGE_DIR), headless: CLAUDE_HEADLESS }));
});

// 한 작업의 실패(예: 크롬 다운로드 오류)가 서버 전체를 죽이지 않도록
process.on("uncaughtException", (e) => {
  console.error("[오류]", e.message);
  for (const j of jobs.values()) if (j.status === "rendering") { j.status = "error"; j.error = e.message; log(j, e.message); }
});
process.on("unhandledRejection", (e) => console.error("[오류]", e && e.message));

const server = app.listen(PORT, HOST, () => {
  console.log(`
BUYEST 영상 스튜디오 v${LOCAL_VERSION} 실행 중`);
  console.log(`  주소: http://localhost:${PORT}  (이 PC에서만 열립니다)`);
});
server.on("error", (e) => {
  if (e.code === "EADDRINUSE") { console.log("이미 실행 중입니다. 브라우저에서 http://localhost:" + PORT + " 를 여세요."); process.exit(0); }
  throw e;
});
