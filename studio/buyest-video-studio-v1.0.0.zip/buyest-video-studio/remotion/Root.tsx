import React from "react";
import { Composition } from "remotion";
import { ProductReel, ProductReelProps, FPS, reelDuration } from "./ProductReel";

const defaults: ProductReelProps = {
  brand: "buyest",
  brandName: "BRAND",
  productName: "Product name",
  price: "₩0",
  cta: "DM으로 문의주세요",
  secondsPerPhoto: 2.5,
  photos: [],
};

export const RemotionRoot: React.FC = () => (
  <Composition
    id="ProductReel"
    component={ProductReel}
    width={1080}
    height={1920}
    fps={FPS}
    durationInFrames={reelDuration(defaults)}
    defaultProps={defaults}
    calculateMetadata={({ props }) => ({ durationInFrames: reelDuration(props) })}
  />
);
