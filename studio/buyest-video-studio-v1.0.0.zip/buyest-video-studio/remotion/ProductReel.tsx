import React from "react";
import { AbsoluteFill, Img, Sequence, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";

export const FPS = 30;
const INTRO_S = 1.2;
const OUTRO_S = 2.5;

export type ProductReelProps = {
  brand: "buyest" | "kids";
  brandName: string;
  productName: string;
  price: string;
  cta: string;
  secondsPerPhoto: number;
  photos: string[];
};

export const reelDuration = (p: ProductReelProps) =>
  Math.round((INTRO_S + Math.max(p.photos.length, 1) * p.secondsPerPhoto + OUTRO_S) * FPS);

const THEMES = {
  buyest: { bg: "#0d0d0d", fg: "#f5f1ea", accent: "#c8a96a", label: "BUYEST", font: "'Didot','Bodoni 72','Times New Roman',serif" },
  kids: { bg: "#fbf6ef", fg: "#2b2b2b", accent: "#e8a0a0", label: "BUYEST KIDS", font: "'Avenir Next','Helvetica Neue',Arial,sans-serif" },
};

const Photo: React.FC<{ src: string; index: number; frames: number }> = ({ src, index, frames }) => {
  const f = useCurrentFrame();
  const zoomIn = index % 2 === 0;
  const scale = interpolate(f, [0, frames], zoomIn ? [1.0, 1.12] : [1.12, 1.0]);
  const x = interpolate(f, [0, frames], index % 3 === 0 ? [-20, 20] : [20, -20]);
  const opacity = interpolate(f, [0, 8, frames - 8, frames], [0, 1, 1, 0], { extrapolateRight: "clamp" });
  return (
    <AbsoluteFill style={{ opacity }}>
      <Img src={src} style={{ width: "100%", height: "100%", objectFit: "cover", transform: `scale(${scale}) translateX(${x}px)` }} />
    </AbsoluteFill>
  );
};

export const ProductReel: React.FC<ProductReelProps> = (props) => {
  const { fps } = useVideoConfig();
  const frame = useCurrentFrame();
  const t = THEMES[props.brand] ?? THEMES.buyest;
  const intro = Math.round(INTRO_S * fps);
  const per = Math.round(props.secondsPerPhoto * fps);
  const outroStart = intro + per * props.photos.length;
  const pop = (start: number) => spring({ frame: frame - start, fps, config: { damping: 200 } });

  return (
    <AbsoluteFill style={{ backgroundColor: t.bg, color: t.fg, fontFamily: t.font }}>
      {/* 인트로: 브랜드 라벨 */}
      <Sequence durationInFrames={intro}>
        <AbsoluteFill style={{ justifyContent: "center", alignItems: "center" }}>
          <div style={{ fontSize: 96, letterSpacing: 18, opacity: pop(0), transform: `translateY(${(1 - pop(0)) * 40}px)` }}>{t.label}</div>
          <div style={{ width: 160 * pop(6), height: 3, background: t.accent, marginTop: 28 }} />
        </AbsoluteFill>
      </Sequence>

      {/* 상품 사진 슬라이드 (팬/줌) */}
      {props.photos.map((src, i) => (
        <Sequence key={i} from={intro + i * per} durationInFrames={per}>
          <Photo src={src} index={i} frames={per} />
        </Sequence>
      ))}

      {/* 하단 고정 캡션 (사진 구간) */}
      <Sequence from={intro} durationInFrames={outroStart - intro}>
        <AbsoluteFill style={{ justifyContent: "flex-end" }}>
          <div style={{ background: `linear-gradient(transparent, ${t.bg}ee)`, padding: "200px 72px 140px" }}>
            <div style={{ fontSize: 44, letterSpacing: 8, color: t.accent }}>{props.brandName.toUpperCase()}</div>
            <div style={{ fontSize: 64, marginTop: 12, lineHeight: 1.2 }}>{props.productName}</div>
          </div>
        </AbsoluteFill>
      </Sequence>

      {/* 아웃트로: 가격 + CTA */}
      <Sequence from={outroStart}>
        <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", textAlign: "center", padding: 80 }}>
          <div style={{ fontSize: 48, letterSpacing: 10, color: t.accent, opacity: pop(outroStart) }}>{props.brandName.toUpperCase()}</div>
          <div style={{ fontSize: 72, marginTop: 24, opacity: pop(outroStart + 4) }}>{props.productName}</div>
          {props.price && <div style={{ fontSize: 110, marginTop: 48, fontWeight: 600, opacity: pop(outroStart + 10) }}>{props.price}</div>}
          {props.cta && (
            <div style={{ marginTop: 64, fontSize: 44, padding: "22px 48px", border: `2px solid ${t.accent}`, borderRadius: 999, opacity: pop(outroStart + 18) }}>
              {props.cta}
            </div>
          )}
          <div style={{ position: "absolute", bottom: 120, fontSize: 36, letterSpacing: 12, opacity: 0.7 }}>{t.label}</div>
        </AbsoluteFill>
      </Sequence>
    </AbsoluteFill>
  );
};
